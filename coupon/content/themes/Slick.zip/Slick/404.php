<div class="pt50 pb50">

<div class="pt-100 pb-100 clearfix">
    <div class="container text-center">
        <h1 class="mb-25"><?php te( 'theme_error_404', 'ERROR 404' ); ?></h1>
        <h3><?php te( 'theme_error_404_msg', "This page you are looking for can't be found." ); ?></h3>
    </div>
</div>

</div>