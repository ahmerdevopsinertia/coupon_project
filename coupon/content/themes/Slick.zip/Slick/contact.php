<div class="bgGray">
    <div class="hero-title">
        <div class="container">
            <h2><?php te( 'theme_contact_title', 'Contact Us' ); ?></h2>
        </div>
    </div>
</div>

<div class="pt-75 pb-75 clearfix">
    <div class="container">
        <div class="form-box">
            <?php echo contact_form(); ?>
        </div>
    </div>
</div>