<div class="bgGray">
    <div class="hero-title">
        <div class="container">
            <h2><?php echo title(); ?></h2>
        </div>
    </div>
</div>

<div class="pt-75 pb-75 clearfix">
    <div class="container">
    <?php echo content(); ?>
    </div>
</div>